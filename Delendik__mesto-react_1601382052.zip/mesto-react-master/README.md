# Проект: Место

**Интро**

Аналогичный сайт https://delendik.github.io/mesto/, написанный на React

**Технологии при создании сайта**

При написании данного сайта использовались:
-ul - React 
-ul - Flexbox  
-ul - Grid Layout  
-ul - псевдокласс :hover  
-ul - добавление, удаление и like карточек с помощью JavaScript  
-ul - popap-ы с помощью JavaScript  
-ul - валидация инпутов  с помощью JavaScript  
-ul - использовано ООП для создания карточек   
-ul - использовано ООП для валидации инпутов 
-ul - внедрены промисы  
-ul - работа с API 

**Результат**

Проект: https://github.com/Delendik/mesto-react




