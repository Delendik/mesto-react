import React from 'react';

function Footer(){
  return(
    <footer className="footer">
      &copy; 2020 Mesto Russia
    </footer>
  )
}

export default Footer;